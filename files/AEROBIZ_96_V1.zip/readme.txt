           ______ _____   ____  ____ _____ ______  _ ___    __  
     /\   |  ____|  __ \ / __ \|  _ \_   _|___  / ( ) _ \  / /  
    /  \  | |__  | |__) | |  | | |_) || |    / /  |/ (_) |/ /_  
   / /\ \ |  __| |  _  /| |  | |  _ < | |   / /     \__, | '_ \ 
  / ____ \| |____| | \ \| |__| | |_) || |_ / /__      / /| (_) |
 /_/    \_\______|_|  \_\\____/|____/_____/_____|    /_/  \___/ 


---

- Air Management '96 - English Translation Patch (Complete)
- Version 1.0 - by DissentKindly

-- About This Project

This patch represents many weeks of dedicated work to bring Air Management '96 (エアーマネジメント'96), originally released exclusively in Japanese for the Sony PlayStation in 1996, into English for the second time, and for the very first time in a complete form - as Aerobiz '96.

--- The Series

Air Management '96 is a sequel, remake and reimagining of KOEI's Aerobiz series of airline management simulation games. The original Aerobiz (Air Management: Ōzora ni Kakeru) launched in 1992 for the Super NES and Mega Drive/Genesis, followed by its sequel, Aerobiz Supersonic, in 1994. Both titles saw Western releases and gained a cult following among strategy fans.

Air Management '96 overhauled the entire experience with enhanced 3D graphics, improved audio, new cutscenes, a rotatable globe for route planning, and new events exclusive to this version. Despite plans to localize the game for Western audiences under the title "Aerobiz 2000", it never saw a release outside of Japan - until now.

--- What This Patch Does

This translation builds upon the foundational work of Lady Jessica, whose v0.8 English translation patch laid the groundwork for bringing this game to a wider audience. Full credit and sincere thanks go to Lady Jessica for her pioneering effort on this project.

This patch completes what that initial release started by:

* Translating all remaining untranslated elements, including button graphics, UI art, and other visual assets that were previously left in Japanese.
* Refitting and polishing the English text to properly fit within dialogue boxes and interface elements, eliminating most of the text clipping and overflow issues present in the earlier patch.
* Ensuring the entire game is fully playable and navigable in English, from menus to operational controls.

What's changed:

* Translated every remaining Japanese button - skill level, player count, company editing, change route, slot negotiation, fleet, stocks, promotion, budget and meeting

* Title screen now reads AEROBIZ, the name the series shipped under in the West, in the original's chrome style. The intro movie matches too
* Circle and Cross swapped to the Western standard, so Cross confirms and Circle cancels
* Clearer city info - the cryptic Blnc / Rsrt / Bsns are now Mixed, Resort and Biz
* Fixed the slot negotiation fee text
* Fixed 46 messages that ran past the bottom of the text box and left stray text stuck on screen underneath the next one

---

-- A Word from the Author

This project was made out of a genuine love for this style of games and for the community of players who want to experience and enjoy these games but are held back by the language barrier. I've been privately working on translations and game improvements like this for a while now, and my goal has always been simple: to help more people play and enjoy games that were never made accessible to them, or enjoy those that were moreso.

This work is not done for profit. However, the reality is that projects like these come with real costs - tools, resources, and assistance that I have been paying for entirely out of my own pocket. I've reached a point where my personal funds can no longer sustain this alone.

If you've enjoyed this patch, or if you'd like to see more projects like this in the future, any support you can offer would be deeply appreciated. Your contributions go directly toward covering operational expenses so that I can continue doing what I love: bringing the greatest games to more people.

You can support this work through my Ko-fi page:

https://ko-fi.com/dissentkindly

Whatever you can give - even if it's just sharing this project with others - means the world to me. Thank you in advance.

---

-- Legal Disclaimer

Air Management '96 and the Aerobiz series are intellectual properties of KOEI (now KOEI Tecmo Holdings). This translation patch is a fan-made project created for personal, non-commercial use only. It is not affiliated with, endorsed by, or sponsored by KOEI or any of its subsidiaries. All trademarks, characters, assets, and associated rights remain the property of their respective owners. This patch is provided free of charge and must not be sold or bundled for profit. Please support the official releases where available.

---

-- A Note on AI Assistance

I want to be transparent about the fact that AI language models were used as a tool during the development of this patch. They assisted with generating translation text, working through technical challenges, and prototyping solutions - tasks that would have taken significantly longer to accomplish alone.
However, I want to be equally clear about what that means in practice. AI models cannot see the games they produce text for. They cannot test patches nor playtest them, spot all visual glitches, or verify completely by itself that a translated string fits correctly on screen. Every bug in this patch - text clipping, graphical artifacts, encoding errors, layout issues - was identified and resolved through extensive manual testing and iteration on my end. The AI provided draft work and technical assistance; the direction, quality assurance, and final decisions were mine.

In other words, this was a collaborative effort between human oversight and machine assistance, not one or the other. I believe in being upfront about that, and I hope the results speak for themselves.

---

-- Bugs!

You can report bugs at the mod thread at https://romhack.ing/forum/topic/IycZ1p8Bin1Qvg_K4b2R .

---